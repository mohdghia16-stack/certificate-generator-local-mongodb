require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const Certificate = require('./models/Certificate');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// ========== LOCAL MONGODB CONNECTION ==========
// Default local connection string
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/certificateDB';

mongoose.connect(MONGODB_URI)
  .then(() => console.log('✅ Connected to Local MongoDB'))
  .catch(err => {
    console.error('❌ MongoDB connection error:', err.message);
    console.log('\n👉 Make sure MongoDB is running on your computer.');
    console.log('   Start it with: mongod   or open MongoDB Compass');
    process.exit(1);
  });

// Generate unique Certificate ID
function generateId() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let id = 'UC-';
  for (let i = 0; i < 8; i++) {
    id += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return id;
}

// ========== ROUTES ==========

// Health check
app.get('/', (req, res) => {
  res.json({ message: 'Certificate Generator API is running (Local MongoDB)', status: 'OK' });
});

// Create / Issue a certificate
app.post('/api/certificates', async (req, res) => {
  try {
    const { name, course, date, org, sign, theme } = req.body;

    if (!name || !course || !date) {
      return res.status(400).json({ error: 'Name, course and date are required' });
    }

    // Generate unique ID (retry if collision)
    let id;
    let exists = true;
    while (exists) {
      id = generateId();
      exists = await Certificate.findOne({ id });
    }

    const cert = new Certificate({
      id,
      name: name.trim(),
      course: course.trim(),
      date,
      org: (org || '').trim(),
      sign: (sign || '').trim(),
      theme: theme || 'classic'
    });

    await cert.save();
    res.status(201).json(cert);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create certificate' });
  }
});

// Get all certificates
app.get('/api/certificates', async (req, res) => {
  try {
    const certs = await Certificate.find().sort({ createdAt: -1 });
    res.json(certs);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch certificates' });
  }
});

// Get one certificate by ID (for verification)
app.get('/api/certificates/:id', async (req, res) => {
  try {
    const cert = await Certificate.findOne({ id: req.params.id.toUpperCase() });
    if (!cert) {
      return res.status(404).json({ error: 'Certificate not found' });
    }
    res.json(cert);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch certificate' });
  }
});

// Delete a certificate (optional)
app.delete('/api/certificates/:id', async (req, res) => {
  try {
    const result = await Certificate.findOneAndDelete({ id: req.params.id.toUpperCase() });
    if (!result) {
      return res.status(404).json({ error: 'Certificate not found' });
    }
    res.json({ message: 'Certificate deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete certificate' });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
  console.log(`📦 Using Local MongoDB: ${MONGODB_URI}`);
});
