const mongoose = require('mongoose');

const certificateSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
    unique: true
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  course: {
    type: String,
    required: true,
    trim: true
  },
  date: {
    type: String,
    required: true
  },
  org: {
    type: String,
    default: ''
  },
  sign: {
    type: String,
    default: ''
  },
  theme: {
    type: String,
    default: 'classic',
    enum: ['classic', 'modern', 'royal', 'minimal', 'emerald']
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Certificate', certificateSchema);
