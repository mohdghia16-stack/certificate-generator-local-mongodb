# Certificate Generator & Verifier (Local MongoDB)

**Developed by Mohammed Taher**  
**Roll No: 244BCA196**  
**Guided by: Prof. Nidhi Patel**

This version uses **Local MongoDB** (easier for college projects).

---

## Project Structure

```
certificate-local-mongo/
├── backend/
│   ├── models/Certificate.js
│   ├── server.js
│   ├── package.json
│   └── .env.example
├── frontend/
│   └── index.html
└── README.md
```

---

## Requirements

1. **Node.js** installed (https://nodejs.org)
2. **MongoDB** installed locally

---

## How to Install MongoDB (Windows - Easy Way)

### Option A: MongoDB Community Edition
1. Download from → https://www.mongodb.com/try/download/community
2. Install it (keep default settings)
3. After installation, MongoDB usually runs automatically as a service

### Option B: Using MongoDB Compass (Recommended for beginners)
1. Download MongoDB Compass → https://www.mongodb.com/try/download/compass
2. Install and open it
3. It will connect to `mongodb://127.0.0.1:27017` automatically

---

## Setup & Run (Step by Step)

### 1. Backend Setup

Open terminal / command prompt in the `backend` folder and run:

```bash
npm install
```

Then start the server:

```bash
npm start
```

You should see:

```
✅ Connected to Local MongoDB
🚀 Server running on http://localhost:5000
```

**Keep this terminal open.**

### 2. Open Frontend

Go to the `frontend` folder and open `index.html` in Chrome or Edge.

---

## How to Use

1. **Issue** tab → Fill details → Choose theme → Save
2. **Issued** tab → See all certificates stored in local MongoDB
3. **Verify** tab → Enter Certificate ID → Verify
4. Download PDF anytime

---

## Technologies Used

- Frontend: HTML5, CSS3, JavaScript
- Backend: Node.js + Express
- Database: **Local MongoDB**
- PDF: html2canvas + jsPDF

---

## API Endpoints

| Method | Endpoint              | Description            |
|--------|-----------------------|------------------------|
| POST   | /api/certificates     | Create certificate     |
| GET    | /api/certificates     | Get all certificates   |
| GET    | /api/certificates/:id | Verify by ID           |
| DELETE | /api/certificates/:id | Delete certificate     |

---

Made by Mohammed Taher (244BCA196)
